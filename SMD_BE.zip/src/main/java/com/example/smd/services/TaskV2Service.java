package com.example.smd.services;

import com.example.smd.dto.request.taskV2.*;
import com.example.smd.dto.response.SourceResponse;
import com.example.smd.dto.response.SprintCurriculumResponse;
import com.example.smd.dto.response.TaskV2Response;
import com.example.smd.entities.*;
import com.example.smd.enums.*;
import com.example.smd.exception.AppException;
import com.example.smd.exception.ErrorCode;
import com.example.smd.mapper.SourceMapper;
import com.example.smd.mapper.TaskV2Mapper;
import com.example.smd.repositories.*;
import com.example.smd.dto.request.NotificationRequest;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class TaskV2Service {

    TaskV2Repository taskV2Repository;
    SubjectRepository subjectRepository;
    SyllabusRepository syllabusRepository;
    CurriculumRepository curriculumRepository;
    DocumentRepository documentRepository;
    SprintRepository sprintRepository;
    AccountRepository accountRepository;
    TaskV2Mapper taskV2Mapper;
    AccountService accountService;
    CurriculumGroupSubjectRepository curriculumGroupSubjectRepository;
    NotificationService notificationService;
    CLOsRepository closRepository;
    ProposedSourceRepository proposedSourceRepository;
    SourceMapper sourceMapper;


    // ===================== GET ALL =====================

    @Transactional(readOnly = true)
    public Page<TaskV2Response> getAllTasks(String search, String status, UUID sprintId, String type, String action,
                                           UUID assignTo, UUID createdBy, UUID targetId, Pageable pageable) {
        Specification<TaskV2> spec = TaskV2Specification.withFilters(search, status, sprintId, type, action, assignTo, createdBy, targetId);
        Page<TaskV2> taskPage = taskV2Repository.findAll(spec, pageable);

        List<TaskV2> tasks = taskPage.getContent();
        if (tasks.isEmpty()) {
            return new PageImpl<>(Collections.emptyList(), pageable, taskPage.getTotalElements());
        }

        // Collect targetIds by type for batch loading
        Set<UUID> subjectIds  = new HashSet<>();
        Set<UUID> syllabusIds = new HashSet<>();
        Set<UUID> curriculumIds = new HashSet<>();
        Set<UUID> documentIds = new HashSet<>();

        for (TaskV2 task : tasks) {
            if (task.getTargetId() != null && task.getType() != null) {
                switch (task.getType()) {
                    case "SUBJECT":     subjectIds.add(task.getTargetId());    break;
                    case "SYLLABUS":    syllabusIds.add(task.getTargetId());   break;
                    case "CURRICULUM":  curriculumIds.add(task.getTargetId()); break;
                    case "MAJOR":       documentIds.add(task.getTargetId());   break;
                }
            }
        }

        // Batch fetch
        Map<UUID, Subject> subjectMap = subjectIds.isEmpty() ? Collections.emptyMap() :
                subjectRepository.findAllById(subjectIds).stream().collect(Collectors.toMap(Subject::getSubjectId, s -> s));

        Map<UUID, Syllabus> syllabusMap = syllabusIds.isEmpty() ? Collections.emptyMap() :
                syllabusRepository.findAllById(syllabusIds).stream().collect(Collectors.toMap(Syllabus::getSyllabusId, s -> s));

        Map<UUID, Curriculum> curriculumMap = curriculumIds.isEmpty() ? Collections.emptyMap() :
                curriculumRepository.findAllById(curriculumIds).stream().collect(Collectors.toMap(Curriculum::getCurriculumId, c -> c));

        Map<UUID, Document> documentMap = documentIds.isEmpty() ? Collections.emptyMap() :
                documentRepository.findAllById(documentIds).stream().collect(Collectors.toMap(Document::getDocumentId, d -> d));

        List<TaskV2Response> responses = tasks.stream()
                .map(task -> enrichResponse(taskV2Mapper.toResponse(task), task.getType(), task.getTargetId(),
                        subjectMap, syllabusMap, curriculumMap, documentMap))
                .collect(Collectors.toList());

        return new PageImpl<>(responses, pageable, taskPage.getTotalElements());
    }

    // ===================== GET BY ID =====================

    @Transactional(readOnly = true)
    public TaskV2Response getTaskById(UUID taskId) {
        TaskV2 task = taskV2Repository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        TaskV2Response response = taskV2Mapper.toResponse(task);

        if (task.getTargetId() != null && task.getType() != null) {
            switch (task.getType()) {
                case "SUBJECT":
                    subjectRepository.findById(task.getTargetId()).ifPresent(sub ->
                            response.setSubject(buildSubjectDto(sub)));
                    break;
                case "SYLLABUS":
                    syllabusRepository.findById(task.getTargetId()).ifPresent(s -> {
                        response.setSyllabus(TaskV2Response.SyllabusDto.builder()
                                .syllabusId(s.getSyllabusId())
                                .syllabusName(s.getSyllabusName())
                                .status(s.getStatus())
                                .build());
                        if (s.getSubject() != null) {
                            response.setSubject(buildSubjectDto(s.getSubject()));
                        }
                    });
                    break;
                case "CURRICULUM":
                    curriculumRepository.findById(task.getTargetId()).ifPresent(c ->
                            response.setCurriculum(TaskV2Response.CurriculumDto.builder()
                                    .curriculumId(c.getCurriculumId())
                                    .curriculumCode(c.getCurriculumCode())
                                    .curriculumName(c.getCurriculumName())
                                    .build()));
                    break;
                case "MAJOR":
                    documentRepository.findById(task.getTargetId()).ifPresent(d ->
                            response.setDocument(TaskV2Response.DocumentDto.builder()
                                    .documentId(d.getDocumentId())
                                    .documentUrl(d.getDocumentUrl())
                                    .build()));
                    break;
            }
        }

        return response;
    }

    // ===================== CREATE =====================

    @Transactional
    public TaskV2Response createTask(TaskV2CreateRequest request, String userId) {
        TaskV2 task = taskV2Mapper.toEntity(request);
        task.setStatus(TaskStatus.TO_DO.name());
        task.setCreatedBy(accountRepository.findById(UUID.fromString(userId))
                .orElseThrow(() -> new RuntimeException("Account (createdBy) not found")));

        if (request.getSprintId() != null) {
            task.setSprint(sprintRepository.findById(request.getSprintId())
                    .orElseThrow(() -> new RuntimeException("Sprint not found")));
        }

        if (request.getAssignTo() != null) {
            task.setAccount(accountRepository.findById(request.getAssignTo())
                    .orElseThrow(() -> new RuntimeException("Account (assignTo) not found")));
        }

        TaskV2 savedTask = taskV2Repository.save(task);

        // Nếu type=SYLLABUS và action=CREATE: update CLO status từ DRAFT -> INTERNAL_REVIEW
        if (TaskType.SYLLABUS.name().equals(request.getType()) && ActionType.CREATE.name().equals(request.getAction())) {
            if (request.getTargetId() != null) {
                var syllabus =
                        syllabusRepository.findByIdWithSubject(request.getTargetId()).orElseThrow();
                    if (syllabus.getSubject() != null) {
                        UUID subjectId = syllabus.getSubject().getSubjectId();
                        List<CLOs> clos = closRepository.findBySubject_SubjectId(subjectId);
                        for (CLOs clo : clos) {
                            if (PloStatus.DRAFT.name().equals(clo.getStatus())) {
                                clo.setStatus(PloStatus.INTERNAL_REVIEW.name());
                            }
                        }
                        closRepository.saveAll(clos);
                    }
                    if (syllabus.getStatus() !=null && !SyllabusStatus.DRAFT.name().equals(syllabus.getStatus())) {
                        syllabus.setStatus(SyllabusStatus.DRAFT.name());
                        syllabusRepository.save(syllabus);
                    }
            }
        }

        //Action MODIFY, Type Subject --> set các CLOs liên quan về DRAFT
        if (TaskType.SUBJECT.name().equals(request.getType()) && ActionType.MODIFY.name().equals(request.getAction())) {
            if (request.getTargetId() != null) {
                List<CLOs> clos = closRepository.findBySubject_SubjectId(request.getTargetId());
                if(clos != null) {
                    for (CLOs clo : clos) {
                        if (!PloStatus.DRAFT.name().equals(clo.getStatus())) {
                            clo.setStatus(PloStatus.DRAFT.name());
                        }
                    }
                    closRepository.saveAll(clos);
                }
            }
        }

        if (savedTask.getAccount() != null) {
            NotificationRequest notifReq = NotificationRequest.builder()
                    .title("New Task")
                    .message("You have been assigned a new task: " + savedTask.getTaskName())
                    .type(NotificationType.TASK)
                    .accountId(savedTask.getAccount().getAccountId())
                    .build();
            notificationService.createNotification(notifReq);
        }

        return getTaskById(savedTask.getTaskId());
    }

    // ===================== UPDATE =====================

    @Transactional
    public TaskV2Response updateTask(UUID taskId, TaskV2UpdateRequest request) {
        TaskV2 task = taskV2Repository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        taskV2Mapper.updateEntity(task, request);

        if (request.getAssignTo() != null) {
            task.setAccount(accountRepository.findById(request.getAssignTo())
                    .orElseThrow(() -> new RuntimeException("Account (assignTo) not found")));
        } else {
            task.setAccount(null);
        }
        task.setIsAccepted(null);

        applyCompletedAt(task);

        TaskV2 savedTask = taskV2Repository.save(task);

        return getTaskById(savedTask.getTaskId());
    }

    // ===================== UPDATE STATUS =====================

    @Transactional
    public TaskV2Response updateTaskStatus(UUID taskId,
                                           String request) {
        log.info("Updating status of task {} to {}", taskId, request);
        TaskV2 task = taskV2Repository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        if (request != null) {
            task.setStatus(request);
        }

        applyCompletedAt(task);

        TaskV2 savedTask = taskV2Repository.save(task);

        // ===================== STATUS PROPAGATION =====================
        // Áp dụng khi type là SUBJECT hoặc SYLLABUS
        String taskType   = task.getType();
        String taskAction = task.getAction();
        String newStatus  = task.getStatus();

        boolean isSubjectOrSyllabus = TaskType.SUBJECT.name().equals(taskType)
                || TaskType.SYLLABUS.name().equals(taskType);

        if (isSubjectOrSyllabus && task.getTargetId() != null) {

            boolean isCreateAction = ActionType.CREATE.name().equals(taskAction);
            boolean isUpdateAction = ActionType.UPDATE.name().equals(taskAction);

            boolean isInProgressOrTodo = TaskStatus.IN_PROGRESS.name().equals(newStatus)
                    || TaskStatus.TO_DO.name().equals(newStatus);
            boolean isDone = TaskStatus.DONE.name().equals(newStatus);

            // ---------- Action: CREATE ----------
            if (isCreateAction) {

                if (isInProgressOrTodo) {
                    // Subject: nếu khác WAITING_SYLLABUS → chuyển sang WAITING_SYLLABUS
                    if (TaskType.SUBJECT.name().equals(taskType)) {
                        subjectRepository.findById(task.getTargetId()).ifPresent(subject -> {
                            if (!SubjectStatus.WAITING_SYLLABUS.name().equals(subject.getStatus())) {
                                subject.setStatus(SubjectStatus.WAITING_SYLLABUS.name());
                                subjectRepository.save(subject);
                                log.info("Subject {} status → WAITING_SYLLABUS", subject.getSubjectId());
                            }
                        });
                    }
                    // Syllabus: nếu khác DRAFT → chuyển về DRAFT
                    if (TaskType.SYLLABUS.name().equals(taskType)) {
                        syllabusRepository.findById(task.getTargetId()).ifPresent(syllabus -> {
                            if (!SyllabusStatus.DRAFT.name().equals(syllabus.getStatus())) {
                                syllabus.setStatus(SyllabusStatus.DRAFT.name());
                                syllabusRepository.save(syllabus);
                                log.info("Syllabus {} status → DRAFT", syllabus.getSyllabusId());
                            }
                        });
                    }
                }

                if (isDone) {
                    // Subject: nếu khác PENDING_REVIEW → chuyển sang PENDING_REVIEW
                    if (TaskType.SUBJECT.name().equals(taskType)) {
                        subjectRepository.findById(task.getTargetId()).ifPresent(subject -> {
                            if (!SubjectStatus.PENDING_REVIEW.name().equals(subject.getStatus())) {
                                subject.setStatus(SubjectStatus.PENDING_REVIEW.name());
                                subjectRepository.save(subject);
                                log.info("Subject {} status → PENDING_REVIEW", subject.getSubjectId());
                            }
                        });
                    }
                    // Syllabus: nếu khác PENDING_REVIEW → chuyển sang PENDING_REVIEW
                    if (TaskType.SYLLABUS.name().equals(taskType)) {
                        syllabusRepository.findById(task.getTargetId()).ifPresent(syllabus -> {
                            if (!SyllabusStatus.PENDING_REVIEW.name().equals(syllabus.getStatus())) {
                                syllabus.setStatus(SyllabusStatus.PENDING_REVIEW.name());
                                syllabusRepository.save(syllabus);
                                log.info("Syllabus {} status → PENDING_REVIEW", syllabus.getSyllabusId());
                            }
                        });
                    }
                }
            }

            // ---------- Action: UPDATE ----------
            if (isUpdateAction) {

                if (isInProgressOrTodo) {
                    // Subject: giữ nguyên status hiện tại (không thay đổi)
                    // Syllabus: nếu khác DRAFT → chuyển về DRAFT
                    if (TaskType.SYLLABUS.name().equals(taskType)) {
                        syllabusRepository.findById(task.getTargetId()).ifPresent(syllabus -> {
                            if (!SyllabusStatus.DRAFT.name().equals(syllabus.getStatus())) {
                                syllabus.setStatus(SyllabusStatus.DRAFT.name());
                                syllabusRepository.save(syllabus);
                                log.info("Syllabus {} status → DRAFT (UPDATE action)", syllabus.getSyllabusId());
                            }
                        });
                    }
                }

                if (isDone) {
                    // Subject: chuyển sang PENDING_REVIEW
                    if (TaskType.SUBJECT.name().equals(taskType)) {
                        subjectRepository.findById(task.getTargetId()).ifPresent(subject -> {
                            subject.setStatus(SubjectStatus.PENDING_REVIEW.name());
                            subjectRepository.save(subject);
                            log.info("Subject {} status → PENDING_REVIEW (UPDATE action)", subject.getSubjectId());
                        });
                    }
                    // Syllabus: chuyển sang PENDING_REVIEW
                    if (TaskType.SYLLABUS.name().equals(taskType)) {
                        syllabusRepository.findById(task.getTargetId()).ifPresent(syllabus -> {
                            syllabus.setStatus(SyllabusStatus.PENDING_REVIEW.name());
                            syllabusRepository.save(syllabus);
                            log.info("Syllabus {} status → PENDING_REVIEW (UPDATE action)", syllabus.getSyllabusId());
                        });
                    }
                }
            }
        }
        // ===================== END STATUS PROPAGATION =====================

        return getTaskById(savedTask.getTaskId());
    }

    // ===================== UPDATE Accepted  =====================

    @Transactional
    public TaskV2Response updateTaskAccepted(UUID taskId,
                                           Boolean request, String comment) {
        TaskV2 task = taskV2Repository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        if(task.getIsAccepted() != null) {
            throw new RuntimeException("Task acceptance has already been set and cannot be updated again.");
        }

        task.setIsAccepted(request);
        task.setComment(comment);
        applyCompletedAt(task);

        TaskV2 savedTask = taskV2Repository.save(task);

        NotificationRequest notifReq = null;
        if (Boolean.TRUE.equals(request)) {
            notifReq = NotificationRequest.builder()
                    .title("Task was Accepted")
                    .message("The task '" + savedTask.getTaskName() + "' has been accepted.")
                    .type(NotificationType.TASK)
                    .accountId(savedTask.getAccount().getAccountId())
                    .build();
        } else {
            notifReq = NotificationRequest.builder()
                    .title("Task was Rejected")
                    .message("The task '" + savedTask.getTaskName() + "' has been rejected. Please review the comments to know the reason.")
                    .type(NotificationType.TASK)
                    .accountId(savedTask.getAccount().getAccountId())
                    .build();
        }

        notificationService.createNotification(notifReq);

        // ===================== ACCEPTED STATUS PROPAGATION =====================
        if (Boolean.TRUE.equals(request) && task.getTargetId() != null) {
            String taskType = task.getType();

            // Type: SUBJECT → nếu Subject đang PENDING_REVIEW thì chuyển sang COMPLETED
            if (TaskType.SUBJECT.name().equals(taskType)) {
                subjectRepository.findById(task.getTargetId()).ifPresent(subject -> {
                    if (SubjectStatus.PENDING_REVIEW.name().equals(subject.getStatus())) {
                        subject.setStatus(SubjectStatus.COMPLETED.name());
                        subjectRepository.save(subject);
                        log.info("Subject {} status → COMPLETED (task accepted)", subject.getSubjectId());
                    }
                });
            }

            // Type: SYLLABUS → nếu Syllabus đang PENDING_REVIEW thì chuyển sang APPROVED
            if (TaskType.SYLLABUS.name().equals(taskType)) {
                syllabusRepository.findById(task.getTargetId()).ifPresent(syllabus -> {
                    if (SyllabusStatus.PENDING_REVIEW.name().equals(syllabus.getStatus())) {
                        syllabus.setStatus(SyllabusStatus.APPROVED.name());
                        syllabusRepository.save(syllabus);
                        log.info("Syllabus {} status → APPROVED (task accepted)", syllabus.getSyllabusId());
                    }
                });
            }
        }
        // ===================== END =====================

        return getTaskById(savedTask.getTaskId());
    }


    // ===================== GET SPRINT & CURRICULUM BY TASK ID =====================

    @Transactional(readOnly = true)
    public SprintCurriculumResponse getSprintAndCurriculumByTaskId(UUID taskId) {
        TaskV2 task = taskV2Repository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        Sprint sprint = task.getSprint();
        if (sprint == null) {
            throw new RuntimeException("Task does not belong to any sprint");
        }

        // Reload sprint với curriculum để tránh lazy loading issue
        sprint = sprintRepository.findById(sprint.getSprintId())
                .orElseThrow(() -> new RuntimeException("Sprint not found"));

        Curriculum curriculum = sprint.getCurriculum();
        if (curriculum == null) {
            throw new RuntimeException("Sprint does not have an associated curriculum");
        }

        return SprintCurriculumResponse.builder()
                .sprintId(sprint.getSprintId())
                .sprintName(sprint.getSprintName())
                .curriculumId(curriculum.getCurriculumId())
                .curriculumCode(curriculum.getCurriculumCode())
                .build();
    }

    // ===================== DELETE =====================

    @Transactional
    public void deleteTask(UUID taskId) {
        if (!taskV2Repository.existsById(taskId)) {
            throw new RuntimeException("Task not found");
        }
        taskV2Repository.deleteById(taskId);
    }

    // ===================== PRIVATE HELPERS =====================

    /** Tự động set/xóa completedAt theo status DONE */
    private void applyCompletedAt(TaskV2 task) {
        if (TaskStatus.DONE.name().equalsIgnoreCase(task.getStatus())) {
            if (task.getCompletedAt() == null) {
                task.setCompletedAt(LocalDate.now());
            }
        } else {
            task.setCompletedAt(null);
        }
    }

    /** Enrich response với thông tin subject/syllabus/curriculum/document từ batch map */
    private TaskV2Response enrichResponse(TaskV2Response response, String type, UUID targetId,
                                          Map<UUID, Subject> subjectMap,
                                          Map<UUID, Syllabus> syllabusMap,
                                          Map<UUID, Curriculum> curriculumMap,
                                          Map<UUID, Document> documentMap) {
        if (type == null || targetId == null) return response;

        switch (type) {
            case "SUBJECT":
                if (subjectMap.containsKey(targetId)) {
                    response.setSubject(buildSubjectDto(subjectMap.get(targetId)));
                }
                break;
            case "SYLLABUS":
                if (syllabusMap.containsKey(targetId)) {
                    Syllabus s = syllabusMap.get(targetId);
                    response.setSyllabus(TaskV2Response.SyllabusDto.builder()
                            .syllabusId(s.getSyllabusId())
                            .syllabusName(s.getSyllabusName())
                            .status(s.getStatus())
                            .build());
                    if (s.getSubject() != null) {
                        response.setSubject(buildSubjectDto(s.getSubject()));
                    }
                }
                break;
            case "CURRICULUM":
                if (curriculumMap.containsKey(targetId)) {
                    Curriculum c = curriculumMap.get(targetId);
                    response.setCurriculum(TaskV2Response.CurriculumDto.builder()
                            .curriculumId(c.getCurriculumId())
                            .curriculumCode(c.getCurriculumCode())
                            .curriculumName(c.getCurriculumName())
                            .build());
                }
                break;
            case "MAJOR":
                if (documentMap.containsKey(targetId)) {
                    Document d = documentMap.get(targetId);
                    response.setDocument(TaskV2Response.DocumentDto.builder()
                            .documentId(d.getDocumentId())
                            .documentUrl(d.getDocumentUrl())
                            .build());
                }
                break;
        }

        return response;
    }

    /** Build SubjectDto từ Subject entity (bao gồm thông tin department và sources) */
    private TaskV2Response.SubjectDto buildSubjectDto(Subject sub) {
        String deptCode = null;
        String deptName = null;
        if (sub.getDepartment() != null) {
            deptCode = sub.getDepartment().getDepartmentCode();
            deptName = sub.getDepartment().getDepartmentName();
        }

        List<SourceResponse> sources = proposedSourceRepository
                .fetchWithSourceBySubjectId(sub.getSubjectId())
                .stream()
                .map(ps -> sourceMapper.toResponse(ps.getSource()))
                .toList();

        return TaskV2Response.SubjectDto.builder()
                .subjectId(sub.getSubjectId())
                .subjectCode(sub.getSubjectCode())
                .subjectName(sub.getSubjectName())
                .credits(sub.getCredits())
                .departmentCode(deptCode)
                .departmentName(deptName)
                .status(sub.getStatus())
                .sources(sources)
                .build();
    }

    //====================== CREATE BATCH TASKS=====================
    @Transactional
    public boolean createBatch(UUID sprintId, String check) {
        var checkRole = accountService.getAccountById(check);
        String roleName = checkRole.getRole().getRoleName();
        if (!(RoleName.HOCFDC.name().equals(roleName))) {
            throw new AppException(ErrorCode.ACCESS_DENIED_FOR_ROLE);
        }

        // Batch API still requires sprintId in path for all roles
        Sprint sprint = sprintRepository.findById(sprintId)
                .orElseThrow(() -> new AppException(ErrorCode.SPRINT_NOT_FOUND));

        if (sprint.getCurriculum() == null || sprint.getCurriculum().getCurriculumId() == null) {
            throw new AppException(ErrorCode.CURRICULUM_NOT_FOUND);
        }
        if (sprint.getAccount() == null || sprint.getAccount().getDepartment() == null ||
                sprint.getAccount().getDepartment().getDepartmentId() == null) {
            throw new AppException(ErrorCode.DEPARTMENT_NOT_FOUND);
        }

        UUID curriculumId = sprint.getCurriculum().getCurriculumId();
        UUID departmentId = sprint.getAccount().getDepartment().getDepartmentId();

        List<Curriculum_Group_Subject> mappings =
                curriculumGroupSubjectRepository.findByCurriculumIdAndDepartmentId(curriculumId, departmentId);

        Set<UUID> subjectIds = new HashSet<>();
        for (Curriculum_Group_Subject mapping : mappings) {
            if (mapping.getSubject() != null && mapping.getSubject().getSubjectId() != null) {
                subjectIds.add(mapping.getSubject().getSubjectId());
            }
        }

        if (subjectIds.isEmpty()) {
            throw new AppException(ErrorCode.SUBJECT_NOT_FOUND);
        }

        // Query 1 lần: lấy tất cả targetId đã tồn tại trong sprint (cả SUBJECT lẫn SYLLABUS)
        Set<UUID> existingTargetIds = taskV2Repository.findAllTargetIdsInSprint(sprintId);

        Account hopdcAccount = accountRepository
                .findByDepartmentAndRoleName(departmentId, RoleName.HOPDC.name())
                .stream()
                .findFirst()
                .orElse(null);

        List<TaskV2> tasksToSave = new ArrayList<>();
        for (UUID subjectId : subjectIds) {

            Subject subject = subjectRepository.findById(subjectId)
                    .orElseThrow(() -> new AppException(ErrorCode.SUBJECT_NOT_FOUND));

            TaskV2 task = TaskV2.builder()
                    .taskName(subject.getSubjectCode() + " - " + subject.getSubjectName())
                    .description("Create Syllabus and CLOs of " + subject.getSubjectCode())
                    .priority(Priority.HIGH.toString())
                    .build();

            task.setSprint(sprint);
            task.setAction(ActionType.CREATE.name());
            task.setType(TaskType.SUBJECT.name());
            task.setCreatedBy( accountRepository.findById(UUID.fromString(check))
                    .orElseThrow(() -> new AppException(ErrorCode.ACCOUNT_NOT_FOUND)));
            task.setAccount(hopdcAccount);
            task.setTargetId(subject.getSubjectId());
            task.setStatus(TaskStatus.TO_DO.toString());
            var list =
                    syllabusRepository.findBySubject_SubjectIdAndStatus(subjectId, "PUBLISHED");

            Syllabus syllabus = list.isEmpty() ? null : list.get(0);

            if(syllabus != null) {
                if (hopdcAccount == null) {
                    throw new AppException(
                            ErrorCode.ACCOUNT_NOT_FOUND,
                            "No HoPDC account found in this department"
                    );
                }
                task.setType(TaskType.SUBJECT.name());
                task.setAction(ActionType.UPDATE.name());
                task.setPriority("MEDIUM");
                task.setDescription("Mapping CLOs of " + subject.getSubjectCode() + " to new curriculum ");
            }
            task.setTaskName(task.getAction()+" "+task.getType()+":" +
                            " " + subject.getSubjectCode() +" - " + subject.getSubjectName());
            // Skip nếu targetId thực tế (subjectId hoặc syllabusId) đã tồn tại trong sprint
            if (existingTargetIds.contains(task.getTargetId())) {
                continue;
            }

            tasksToSave.add(task);
        }

        if (tasksToSave.isEmpty()) {
            throw new AppException(
                    ErrorCode.TASK_LIST_REQUIRED,
                    "No new tasks can be created for this sprint"
            );
        }

        List<TaskV2> savedTasks = taskV2Repository.saveAll(tasksToSave);

        if (sprint.getAccount() != null &&
                sprint.getAccount().getRole() != null &&
                RoleName.HOPDC.name().equals(sprint.getAccount().getRole().getRoleName())) {
            List<String> taskNames = savedTasks.stream().map(TaskV2::getTaskName).toList();
        }

        if (hopdcAccount != null && !savedTasks.isEmpty()) {
                NotificationRequest notifReq = NotificationRequest.builder()
                        .title("New Department Tasks")
                        .message("You have been assigned a new department tasks: " )
                        .type(NotificationType.TASK)
                        .accountId(hopdcAccount.getAccountId())
                        .build();
                notificationService.createNotification(notifReq);
        }

        return true;
    }

//     ===================== CREATE BY VP =====================
    @Transactional
    public TaskV2Response createByVP(
            TaskV2CreateVPRequest request,
            String userId) {
        TaskV2 task = taskV2Mapper.requestVPtoEntity(request);

        Account account = accountRepository.findFirstByRole_RoleName(RoleName.HOCFDC.name())
                .orElseThrow(() -> new AppException(ErrorCode.ACCOUNT_NOT_FOUND, "No account with role HoCFDC found"));
        task.setAccount(account);
        task.setCreatedBy(accountRepository.findById(UUID.fromString(userId))
                .orElseThrow(() -> new RuntimeException("Account (createdBy) not found")));
        task.setStatus(TaskStatus.TO_DO.name());
        task = taskV2Repository.save(task);

        if (task.getAccount() != null) {
            NotificationRequest notifReq = NotificationRequest.builder()
                    .title("New Task")
                    .message("You have been assigned a new task: " + task.getTaskName())
                    .type(NotificationType.TASK)
                    .accountId(task.getAccount().getAccountId())
                    .build();
            notificationService.createNotification(notifReq);
        }

        return taskV2Mapper.toResponse(task);
    }
}
