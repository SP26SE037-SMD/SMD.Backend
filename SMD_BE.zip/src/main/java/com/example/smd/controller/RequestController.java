package com.example.smd.controller;

import com.example.smd.dto.request.request.RequestCreateForHoCFDCRequest;
import com.example.smd.dto.request.request.RequestCreateForVPRequest;
import com.example.smd.dto.request.request.RequestCreateRequest;
import com.example.smd.dto.request.request.RequestUpdateRequest;
import com.example.smd.dto.response.PagedResponse;
import com.example.smd.dto.response.ResponseObject;
import com.example.smd.dto.response.request.RequestResponse;
import com.example.smd.services.RequestService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/requests")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Tag(name = "Request", description = "Endpoints for managing requests")
@SecurityRequirement(name = "bearerAuth")
public class RequestController {

    RequestService requestService;

    // ------------------------------------------------------------------ CREATE

    @PostMapping("/hocfdc")
    @Operation(summary = "Create a new request for HoCFDC")
    public ResponseObject<RequestResponse> createForHoCFDC(
            @RequestBody @Valid RequestCreateForHoCFDCRequest dto,
            @AuthenticationPrincipal Jwt jwt) {

        String userId = jwt.getClaimAsString("accountId");
        return ResponseObject.<RequestResponse>builder()
                .data(requestService.createForHoCFDC(dto, userId))
                .message("Request created successfully")
                .build();
    }

    @PostMapping("/vp")
    @Operation(summary = "Create a new request for VP")
    public ResponseObject<RequestResponse> createForVP(
            @RequestBody @Valid RequestCreateForVPRequest dto,
            @AuthenticationPrincipal Jwt jwt) {

        String userId = jwt.getClaimAsString("accountId");
        return ResponseObject.<RequestResponse>builder()
                .data(requestService.createForVP(dto, userId))
                .message("Request created successfully")
                .build();
    }

    @PostMapping
    @Operation(summary = "Create a new request")
    public ResponseObject<RequestResponse> create(
            @RequestBody @Valid RequestCreateRequest dto,
            @AuthenticationPrincipal Jwt jwt) {

        String userId = jwt.getClaimAsString("accountId");
        return ResponseObject.<RequestResponse>builder()
                .data(requestService.create(dto, userId))
                .message("Request created successfully")
                .build();
    }


    // ------------------------------------------------------------------ READ

    @GetMapping
    @Operation(summary = "Get all requests with pagination and filtering")
    public ResponseObject<PagedResponse<RequestResponse>> getAll(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) UUID createdById,
            @RequestParam(required = false) UUID receivedById,
            @RequestParam(required = false) UUID targetId,
            @RequestParam(defaultValue = "0")   int page,
            @RequestParam(defaultValue = "10")  int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {

        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);

        return ResponseObject.<PagedResponse<RequestResponse>>builder()
                .data(PagedResponse.of(
                        requestService.getAll(search, status, type, createdById, receivedById, targetId, pageable)))
                .message("Requests retrieved successfully")
                .build();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get request detail by ID")
    public ResponseObject<RequestResponse> getById(@PathVariable UUID id) {
        return ResponseObject.<RequestResponse>builder()
                .data(requestService.getById(id))
                .message("Request retrieved successfully")
                .build();
    }

    // ------------------------------------------------------------------ UPDATE STATUS

    @PatchMapping("/{id}/status")
    @Operation(summary = "Update request status / comment / receivedBy")
    public ResponseObject<RequestResponse> updateStatus(
            @PathVariable UUID id,
            @RequestBody @Valid RequestUpdateRequest dto) {

        return ResponseObject.<RequestResponse>builder()
                .data(requestService.updateStatus(id, dto))
                .message("Request updated successfully")
                .build();
    }

    // ------------------------------------------------------------------ DELETE

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete request")
    public ResponseObject<Void> delete(@PathVariable UUID id) {
        requestService.delete(id);
        return ResponseObject.<Void>builder()
                .message("Request deleted successfully")
                .build();
    }
}
