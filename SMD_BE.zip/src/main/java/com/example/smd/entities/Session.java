package com.example.smd.entities;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "session")
public class Session {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "session_id")
    UUID sessionId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "syllabus_id", nullable = false)
    Syllabus syllabus;

    @Column(name = "session_number", nullable = false)
    Integer sessionNumber;

    @Column(name = "chapter_title", nullable = false, length = 200)
    String sessionTitle;

    @Column(name = "session_type", nullable = false, length = 200)
    String sessionType;

    @Column(name = "teaching_methods", columnDefinition = "TEXT")
    String teachingMethods;

    @Column(name = "session_topic", columnDefinition = "TEXT")
    String sessionTopic;

    @Column(name = "duration") // in minutes
    Integer duration;

    @Column(name = "created_at")
    Instant createdAt;


    @OneToMany(mappedBy = "session", fetch = FetchType.LAZY)
    List<CLO_Session> cloSessions;


    @PrePersist
    protected void onCreate() {
        this.createdAt = Instant.now();
    }
}
