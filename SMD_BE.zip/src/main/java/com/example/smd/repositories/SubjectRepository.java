package com.example.smd.repositories;

import com.example.smd.entities.Subject;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface SubjectRepository extends JpaRepository<Subject, UUID>, JpaSpecificationExecutor<Subject> {

    // Giữ lại hàm kiểm tra trùng mã môn học hiện có
    boolean existsBySubjectCode(String subjectCode);

    Optional<Subject> findBySubjectCode(String subjectCode);

    // JPQL sử dụng JOIN FETCH để lấy kèm Department và CLOs
    @Query("SELECT DISTINCT s FROM Subject s " +
            "LEFT JOIN FETCH s.department " +
            "LEFT JOIN FETCH s.clos " +
            "WHERE s.subjectId = :id")
    Optional<Subject> findDetailById(@Param("id") UUID id);

    // Đối với danh sách, dùng EntityGraph là cách an toàn nhất để phân trang ở mức Database
    @EntityGraph(attributePaths = {"department", "clos"})
    @Override
    Page<Subject> findAll(Specification<Subject> spec, Pageable pageable);

    @Query("SELECT s FROM Subject s JOIN FETCH s.department WHERE s.department.departmentId = :deptId")
    List<Subject> findAllByDepartmentId(@Param("deptId") UUID deptId);

    List<Subject> findAllByDepartment_DepartmentIdAndStatus(UUID departmentId, String status);
    List<Subject> findAllByDepartment_DepartmentId(UUID departmentId);

    @Modifying
    @Transactional
    @Query(value = """
        UPDATE subjects s
        SET status = :newStatus
        WHERE s.status = :oldStatus
        AND s.department_id = :departmentId
        AND s.subject_id IN (
            SELECT cgs.subject_id
            FROM curriculum_group_subject cgs
            WHERE cgs.curriculum_id = :curriculumId
        )
    """, nativeQuery = true)
    int updateStatusByCurriculumAndDepartmentWithCondition(
            @Param("newStatus") String newStatus,
            @Param("oldStatus") String oldStatus,
            @Param("curriculumId") UUID curriculumId,
            @Param("departmentId") UUID departmentId
    );

    @Modifying
    @Transactional
    @Query(value = """
        UPDATE subjects s
        SET status = :newStatus
        WHERE s.status = :oldStatus
        AND s.subject_id IN (
            SELECT cgs.subject_id
            FROM curriculum_group_subject cgs
            WHERE cgs.curriculum_id = :curriculumId
        )
    """, nativeQuery = true)
    int updateStatusByCurriculumWithCondition(
            @Param("newStatus") String newStatus,
            @Param("oldStatus") String oldStatus,
            @Param("curriculumId") UUID curriculumId
    );

    @Modifying
    @Transactional
    @Query(value = """
        UPDATE subjects s
        SET status = :newStatus
        WHERE s.department_id = :departmentId
        AND s.subject_id IN (
            SELECT cgs.subject_id
            FROM curriculum_group_subject cgs
            WHERE cgs.curriculum_id = :curriculumId
        )
    """, nativeQuery = true)
    int updateStatusByCurriculumAndDepartment(
            @Param("newStatus") String newStatus,
            @Param("curriculumId") UUID curriculumId,
            @Param("departmentId") UUID departmentId
    );

    @Modifying
    @Transactional
    @Query(value = """
        UPDATE subjects s
        SET status = :newStatus
        WHERE s.subject_id IN (
            SELECT cgs.subject_id
            FROM curriculum_group_subject cgs
            WHERE cgs.curriculum_id = :curriculumId
        )
    """, nativeQuery = true)
    int updateStatusByCurriculum(
            @Param("newStatus") String newStatus,
            @Param("curriculumId") UUID curriculumId
    );

    @Modifying
    @Transactional
    @Query(value = """
        UPDATE subjects s
        SET decision_no = :decisionNo,
            approved_date = :approvedDate
        WHERE s.department_id = :departmentId
        AND s.subject_id IN (
            SELECT cgs.subject_id
            FROM curriculum_group_subject cgs
            WHERE cg.curriculum_id = :curriculumId
        )
    """, nativeQuery = true)
    int updateDecisionInfoByCurriculumAndDepartment(
            @Param("decisionNo") String decisionNo,
            @Param("approvedDate") java.time.Instant approvedDate,
            @Param("curriculumId") UUID curriculumId,
            @Param("departmentId") UUID departmentId
    );
}
