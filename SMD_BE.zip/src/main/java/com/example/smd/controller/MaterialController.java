package com.example.smd.controller;

import com.example.smd.dto.request.MaterialRequest;
import com.example.smd.dto.response.MaterialResponse;
import com.example.smd.dto.response.ResponseObject;
import com.example.smd.services.MaterialService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/materials")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Tag(name = "Material", description = "Material Management APIs")
@SecurityRequirement(name = "bearerAuth")
public class MaterialController {
    MaterialService materialService;

    @PostMapping
    @PreAuthorize("hasAuthority('MATERIAL_CREATE')")
    @Operation(summary = "Create new material for a syllabus")
    public ResponseObject<MaterialResponse> create(
            @RequestBody @Valid MaterialRequest request,
            @AuthenticationPrincipal Jwt jwt) {
        String userId = jwt.getClaimAsString("accountId");
        return ResponseObject.<MaterialResponse>builder()
                .status(1000).data(materialService.create(request, userId)).build();
    }

    @GetMapping("/syllabus/{syllabusId}")
    @Operation(summary = "Get all materials by Syllabus ID")
    public ResponseObject<List<MaterialResponse>> getAllBySyllabus(
            @PathVariable UUID syllabusId,
            @AuthenticationPrincipal Jwt jwt) {
        String userId = jwt.getClaimAsString("accountId");
        return ResponseObject.<List<MaterialResponse>>builder()
                .status(1000)
                .data(materialService.getAllBySyllabus(syllabusId, userId))
                .message("Materials retrieved successfully")
                .build();
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('MATERIAL_UPDATE')")
    @Operation(summary = "Update material details")
    public ResponseObject<MaterialResponse> update(
            @PathVariable UUID id,
            @RequestBody MaterialRequest request,
            @AuthenticationPrincipal Jwt jwt) {
        String userId = jwt.getClaimAsString("accountId");
        return ResponseObject.<MaterialResponse>builder()
                .status(1000).data(materialService.update(id, request, userId)).build();
    }



    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('MATERIAL_DELETE')")
    @Operation(summary = "Delete a material")
    public ResponseObject<Void> delete(@PathVariable UUID id, @AuthenticationPrincipal Jwt jwt) {
        String userId = jwt.getClaimAsString("accountId");
        materialService.delete(id, userId);
        return ResponseObject.<Void>builder().status(1000).message("Deleted successfully").build();
    }

    @GetMapping("/{materialId}")
    @Operation(
            summary = "Get detailed information of a Material",
            description = "Retrieves full details of a specific material by its UUID. \n\n" +
                    "### 🔒 Security Note:\n" +
                    "* Public roles (Student/Lecturer) can only access **PUBLISHED** materials.\n" +
                    "* Unauthorized access to DRAFT/ARCHIVED materials will return 403 Forbidden."
    )
    public ResponseObject<MaterialResponse> getDetail(
            @Parameter(description = "UUID of the material to retrieve")
            @PathVariable UUID materialId,
            @AuthenticationPrincipal Jwt jwt) {
        String userId = jwt.getClaimAsString("accountId");
        return ResponseObject.<MaterialResponse>builder()
                .status(1000)
                .data(materialService.getDetail(materialId, userId))
                .message("Material details retrieved successfully")
                .build();
    }

    @GetMapping("/{syllabusId}/chapters/{id}/history")
    @Operation(summary = "Lấy lịch sử tất cả các phiên bản của tài liệu")
    public ResponseObject<List<MaterialResponse>> getMaterialHistory(
            @PathVariable UUID syllabusId,
            @PathVariable int id) {
        return ResponseObject.<List<MaterialResponse>>builder()
                .data(materialService.getAllVersionsById(id, syllabusId))
                .message("Fetched material history successfully")
                .build();
    }
}
